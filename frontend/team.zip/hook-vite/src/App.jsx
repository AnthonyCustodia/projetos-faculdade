import { useState } from "react";
import { MeuContextoProvider } from "./contexts/MeuContexto";
import ValorContexto from "./components/ValorContexto";
import ComponenteFilho from "./components/ComponenteFilho";

function App() {
  const[count, setCount] = useState(0)


  return(
    <MeuContextoProvider>
      <ComponenteFilho></ComponenteFilho>
      <ValorContexto></ValorContexto>
    </MeuContextoProvider>
  )
}

export default App